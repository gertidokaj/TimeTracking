﻿namespace TimeTrackingDemo
{
    partial class AddOrChangeForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelTop = new System.Windows.Forms.Panel();
            this.labelAddNewData = new System.Windows.Forms.Label();
            this.panelBottom = new System.Windows.Forms.Panel();
            this.buttonCancel = new System.Windows.Forms.Button();
            this.buttonOk = new System.Windows.Forms.Button();
            this.labelFullName = new System.Windows.Forms.Label();
            this.labelWorkDay = new System.Windows.Forms.Label();
            this.labelDurationOfWork = new System.Windows.Forms.Label();
            this.labelTypeOfWork = new System.Windows.Forms.Label();
            this.labelComment = new System.Windows.Forms.Label();
            this.comboBoxFullName = new System.Windows.Forms.ComboBox();
            this.dateTimePickerWorkDay = new System.Windows.Forms.DateTimePicker();
            this.comboBoxTypeOfWork = new System.Windows.Forms.ComboBox();
            this.textBoxComment = new System.Windows.Forms.TextBox();
            this.numericUpDownDurationOfWork = new System.Windows.Forms.NumericUpDown();
            this.panelTop.SuspendLayout();
            this.panelBottom.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDurationOfWork)).BeginInit();
            this.SuspendLayout();
            // 
            // panelTop
            // 
            this.panelTop.BackColor = System.Drawing.Color.LightGray;
            this.panelTop.Controls.Add(this.labelAddNewData);
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Location = new System.Drawing.Point(0, 0);
            this.panelTop.Name = "panelTop";
            this.panelTop.Size = new System.Drawing.Size(427, 58);
            this.panelTop.TabIndex = 0;
            // 
            // labelAddNewData
            // 
            this.labelAddNewData.AutoSize = true;
            this.labelAddNewData.BackColor = System.Drawing.Color.Transparent;
            this.labelAddNewData.Font = new System.Drawing.Font("Bahnschrift", 22F, System.Drawing.FontStyle.Bold);
            this.labelAddNewData.ForeColor = System.Drawing.Color.Black;
            this.labelAddNewData.Location = new System.Drawing.Point(105, 9);
            this.labelAddNewData.Name = "labelAddNewData";
            this.labelAddNewData.Size = new System.Drawing.Size(223, 36);
            this.labelAddNewData.TabIndex = 4;
            this.labelAddNewData.Text = "ADD NEW DATA";
            this.labelAddNewData.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelBottom
            // 
            this.panelBottom.BackColor = System.Drawing.Color.LightGray;
            this.panelBottom.Controls.Add(this.buttonCancel);
            this.panelBottom.Controls.Add(this.buttonOk);
            this.panelBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelBottom.Location = new System.Drawing.Point(0, 334);
            this.panelBottom.Name = "panelBottom";
            this.panelBottom.Size = new System.Drawing.Size(427, 58);
            this.panelBottom.TabIndex = 1;
            // 
            // buttonCancel
            // 
            this.buttonCancel.BackColor = System.Drawing.Color.White;
            this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.buttonCancel.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Bold);
            this.buttonCancel.ForeColor = System.Drawing.Color.Black;
            this.buttonCancel.Location = new System.Drawing.Point(238, 10);
            this.buttonCancel.Name = "buttonCancel";
            this.buttonCancel.Size = new System.Drawing.Size(133, 41);
            this.buttonCancel.TabIndex = 2;
            this.buttonCancel.Text = "CANCEL";
            this.buttonCancel.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.buttonCancel.UseVisualStyleBackColor = false;
            this.buttonCancel.Click += new System.EventHandler(this.buttonCancel_Click);
            // 
            // buttonOk
            // 
            this.buttonOk.BackColor = System.Drawing.Color.White;
            this.buttonOk.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.buttonOk.Font = new System.Drawing.Font("Bahnschrift", 18F, System.Drawing.FontStyle.Bold);
            this.buttonOk.ForeColor = System.Drawing.Color.Black;
            this.buttonOk.Location = new System.Drawing.Point(57, 10);
            this.buttonOk.Name = "buttonOk";
            this.buttonOk.Size = new System.Drawing.Size(133, 41);
            this.buttonOk.TabIndex = 1;
            this.buttonOk.Text = "OK";
            this.buttonOk.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.buttonOk.UseVisualStyleBackColor = false;
            this.buttonOk.Click += new System.EventHandler(this.buttonOk_Click);
            // 
            // labelFullName
            // 
            this.labelFullName.AutoSize = true;
            this.labelFullName.BackColor = System.Drawing.Color.Transparent;
            this.labelFullName.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold);
            this.labelFullName.ForeColor = System.Drawing.Color.Black;
            this.labelFullName.Location = new System.Drawing.Point(12, 83);
            this.labelFullName.Name = "labelFullName";
            this.labelFullName.Size = new System.Drawing.Size(101, 19);
            this.labelFullName.TabIndex = 5;
            this.labelFullName.Text = "FULL NAME :";
            this.labelFullName.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelWorkDay
            // 
            this.labelWorkDay.AutoSize = true;
            this.labelWorkDay.BackColor = System.Drawing.Color.Transparent;
            this.labelWorkDay.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold);
            this.labelWorkDay.ForeColor = System.Drawing.Color.Black;
            this.labelWorkDay.Location = new System.Drawing.Point(12, 120);
            this.labelWorkDay.Name = "labelWorkDay";
            this.labelWorkDay.Size = new System.Drawing.Size(93, 19);
            this.labelWorkDay.TabIndex = 6;
            this.labelWorkDay.Text = "WORK DAY :";
            this.labelWorkDay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelDurationOfWork
            // 
            this.labelDurationOfWork.AutoSize = true;
            this.labelDurationOfWork.BackColor = System.Drawing.Color.Transparent;
            this.labelDurationOfWork.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold);
            this.labelDurationOfWork.ForeColor = System.Drawing.Color.Black;
            this.labelDurationOfWork.Location = new System.Drawing.Point(12, 156);
            this.labelDurationOfWork.Name = "labelDurationOfWork";
            this.labelDurationOfWork.Size = new System.Drawing.Size(162, 19);
            this.labelDurationOfWork.TabIndex = 7;
            this.labelDurationOfWork.Text = "DURATION OF WORK :";
            this.labelDurationOfWork.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelTypeOfWork
            // 
            this.labelTypeOfWork.AutoSize = true;
            this.labelTypeOfWork.BackColor = System.Drawing.Color.Transparent;
            this.labelTypeOfWork.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold);
            this.labelTypeOfWork.ForeColor = System.Drawing.Color.Black;
            this.labelTypeOfWork.Location = new System.Drawing.Point(12, 193);
            this.labelTypeOfWork.Name = "labelTypeOfWork";
            this.labelTypeOfWork.Size = new System.Drawing.Size(125, 19);
            this.labelTypeOfWork.TabIndex = 8;
            this.labelTypeOfWork.Text = "TYPE OF WORK :";
            this.labelTypeOfWork.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labelComment
            // 
            this.labelComment.AutoSize = true;
            this.labelComment.BackColor = System.Drawing.Color.Transparent;
            this.labelComment.Font = new System.Drawing.Font("Bahnschrift", 12F, System.Drawing.FontStyle.Bold);
            this.labelComment.ForeColor = System.Drawing.Color.Black;
            this.labelComment.Location = new System.Drawing.Point(12, 233);
            this.labelComment.Name = "labelComment";
            this.labelComment.Size = new System.Drawing.Size(91, 19);
            this.labelComment.TabIndex = 9;
            this.labelComment.Text = "COMMENT :";
            this.labelComment.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // comboBoxFullName
            // 
            this.comboBoxFullName.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxFullName.FormattingEnabled = true;
            this.comboBoxFullName.Location = new System.Drawing.Point(182, 85);
            this.comboBoxFullName.Name = "comboBoxFullName";
            this.comboBoxFullName.Size = new System.Drawing.Size(233, 21);
            this.comboBoxFullName.TabIndex = 10;
            this.comboBoxFullName.SelectedIndexChanged += new System.EventHandler(this.comboBoxFullName_SelectedIndexChanged);
            this.comboBoxFullName.SelectedValueChanged += new System.EventHandler(this.comboBoxFullName_SelectedValueChanged);
            // 
            // dateTimePickerWorkDay
            // 
            this.dateTimePickerWorkDay.Enabled = false;
            this.dateTimePickerWorkDay.Location = new System.Drawing.Point(182, 119);
            this.dateTimePickerWorkDay.Name = "dateTimePickerWorkDay";
            this.dateTimePickerWorkDay.Size = new System.Drawing.Size(233, 20);
            this.dateTimePickerWorkDay.TabIndex = 11;
            this.dateTimePickerWorkDay.ValueChanged += new System.EventHandler(this.dateTimePickerWorkDay_ValueChanged);
            // 
            // comboBoxTypeOfWork
            // 
            this.comboBoxTypeOfWork.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxTypeOfWork.FormattingEnabled = true;
            this.comboBoxTypeOfWork.Location = new System.Drawing.Point(182, 191);
            this.comboBoxTypeOfWork.Name = "comboBoxTypeOfWork";
            this.comboBoxTypeOfWork.Size = new System.Drawing.Size(233, 21);
            this.comboBoxTypeOfWork.TabIndex = 13;
            this.comboBoxTypeOfWork.SelectedValueChanged += new System.EventHandler(this.comboBoxTypeOfWork_SelectedValueChanged);
            // 
            // textBoxComment
            // 
            this.textBoxComment.Location = new System.Drawing.Point(182, 240);
            this.textBoxComment.MaxLength = 255;
            this.textBoxComment.Multiline = true;
            this.textBoxComment.Name = "textBoxComment";
            this.textBoxComment.Size = new System.Drawing.Size(232, 75);
            this.textBoxComment.TabIndex = 14;
            this.textBoxComment.TextChanged += new System.EventHandler(this.textBoxComment_TextChanged);
            // 
            // numericUpDownDurationOfWork
            // 
            this.numericUpDownDurationOfWork.DecimalPlaces = 1;
            this.numericUpDownDurationOfWork.Increment = new decimal(new int[] {
            5,
            0,
            0,
            65536});
            this.numericUpDownDurationOfWork.Location = new System.Drawing.Point(182, 156);
            this.numericUpDownDurationOfWork.Maximum = new decimal(new int[] {
            14,
            0,
            0,
            0});
            this.numericUpDownDurationOfWork.Name = "numericUpDownDurationOfWork";
            this.numericUpDownDurationOfWork.ReadOnly = true;
            this.numericUpDownDurationOfWork.Size = new System.Drawing.Size(233, 20);
            this.numericUpDownDurationOfWork.TabIndex = 15;
            this.numericUpDownDurationOfWork.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numericUpDownDurationOfWork.Value = new decimal(new int[] {
            8,
            0,
            0,
            0});
            this.numericUpDownDurationOfWork.ValueChanged += new System.EventHandler(this.numericUpDownDurationOfWork_ValueChanged);
            // 
            // AddOrChangeForm
            // 
            this.AcceptButton = this.buttonOk;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(427, 392);
            this.Controls.Add(this.numericUpDownDurationOfWork);
            this.Controls.Add(this.textBoxComment);
            this.Controls.Add(this.comboBoxTypeOfWork);
            this.Controls.Add(this.dateTimePickerWorkDay);
            this.Controls.Add(this.comboBoxFullName);
            this.Controls.Add(this.labelComment);
            this.Controls.Add(this.labelTypeOfWork);
            this.Controls.Add(this.labelDurationOfWork);
            this.Controls.Add(this.labelWorkDay);
            this.Controls.Add(this.labelFullName);
            this.Controls.Add(this.panelBottom);
            this.Controls.Add(this.panelTop);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AddOrChangeForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ADD";
            this.Load += new System.EventHandler(this.AddOrChangeForm_Load);
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            this.panelBottom.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDurationOfWork)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Panel panelBottom;
        private System.Windows.Forms.Button buttonCancel;
        private System.Windows.Forms.Label labelFullName;
        private System.Windows.Forms.Label labelWorkDay;
        private System.Windows.Forms.Label labelDurationOfWork;
        private System.Windows.Forms.Label labelTypeOfWork;
        private System.Windows.Forms.Label labelComment;
        public System.Windows.Forms.ComboBox comboBoxFullName;
        public System.Windows.Forms.DateTimePicker dateTimePickerWorkDay;
        public System.Windows.Forms.ComboBox comboBoxTypeOfWork;
        public System.Windows.Forms.TextBox textBoxComment;
        public System.Windows.Forms.NumericUpDown numericUpDownDurationOfWork;
        private System.Windows.Forms.Button buttonOk;
        internal System.Windows.Forms.Label labelAddNewData;
    }
}