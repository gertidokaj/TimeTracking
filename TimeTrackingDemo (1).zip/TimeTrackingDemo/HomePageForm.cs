﻿using Equin.ApplicationFramework;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;

namespace TimeTrackingDemo
{
    public partial class HomePageForm : Form
    {
        BindingList<Record> rList = new BindingList<Record>();
        BindingSource bindingSource = new BindingSource();
        DataTable dataTable = new DataTable();
        internal User user;
        ///declaring rowIndex to use it as a variable in this class
        ///to use when clicking or double-clicking within the datagridview
        private int rowIndex;
        ///declaring and initializing rowRecord to use it as a variable in this class
        ///to be incremented by adding records in the datagridview
        private int rowRecord = 1;

        public HomePageForm()
        {
            InitializeComponent();
            dataTable = SetDataTable();
            bindingSource.DataSource = dataTable;
            advancedDataGridViewRecords.DataSource = bindingSource;
        }

        public DataTable SetDataTable ()
        {
            DataTable dataTable = new DataTable();

            dataTable.Columns.Add("recordID", typeof(int));
            dataTable.Columns.Add("employeeID", typeof(int));
            dataTable.Columns.Add("firstName", typeof(String));
            dataTable.Columns.Add("lastName", typeof(String));
            dataTable.Columns.Add("workDay", typeof(DateTime));
            dataTable.Columns.Add("durationOfWork", typeof(decimal));
            dataTable.Columns.Add("typeOfWork", typeof(String));
            dataTable.Columns.Add("creationDateTime", typeof(DateTime));
            dataTable.Columns.Add("lastUpdatedDateTime", typeof(DateTime));
            dataTable.Columns.Add("comment", typeof(String));

            return dataTable;
        } 
        /// <summary>
        /// This method starts the timer, disable "Change" and "Delete" buttons
        /// and gets the Username label text from user when the HomePageForm() is loaded.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HomePageForm_Load(object sender, EventArgs e)
        {
            timer1.Start();
            DisableChangeDeleteButtons();
            labelUsername.Text = user.username;
        }

        /// <summary>
        /// This method closes the application when the HomePageForm is closing.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HomePageForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        /// <summary>
        /// This method paints the DateTime panel.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void panelDateTime_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, panelDateTime.ClientRectangle, Color.FromArgb(255, 0, 117, 214), ButtonBorderStyle.Solid);
        }

        /// <summary>
        /// This method uses the timer that starts when the HomePageForm() loads to display the current (running) date and time.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void timer1_Tick(object sender, EventArgs e)
        {
            labelDate.Text = DateTime.Now.ToShortDateString();
            labelTime.Text = DateTime.Now.ToLongTimeString();
        }

        /// <summary>
        /// This method uses the AddOrChangeForm() to add a record data in the datagridview.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e">the event of clicking "Add" button</param>
        private void buttonAdd_Click(object sender, EventArgs e)
        {
            using (AddOrChangeForm aoc = new AddOrChangeForm() { record = new Record() })
            {
                if (user.userID != 999)
                {
                    aoc.comboBoxFullName.SelectedIndex = user.userID - 1;
                    aoc.comboBoxFullName.Enabled = false;
                }

                if (aoc.ShowDialog() == DialogResult.OK)
                {
                    aoc.record.recordID = rowRecord;
                    rowRecord++;
                    aoc.record.creationDateTime = DateTime.Now;
                    DataRow dataRow = dataTable.NewRow();
                    dataRow[0] = aoc.record.recordID;
                    dataRow[1] = aoc.record.employeeID;
                    dataRow[2] = aoc.record.firstName;
                    dataRow[3] = aoc.record.lastName;
                    dataRow[4] = aoc.record.workDay;
                    dataRow[5] = aoc.record.durationOfWork;
                    dataRow[6] = aoc.record.typeOfWork;
                    dataRow[7] = aoc.record.creationDateTime;
                    dataRow[8] = aoc.record.lastUpdatedDateTime;
                    dataRow[9] = aoc.record.comment;

                    dataTable.Rows.Add(dataRow);
                }
            }
        }

        /// <summary>
        /// This method calls the method ChangeRecord() when "Change" button is clicked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e">the event of clicking "Change" button</param>
        private void buttonChange_Click(object sender, EventArgs e)
        {
            ChangeRecord();
        }

        /// <summary>
        /// This method deletes a record from the datagridview when the "Delete" button is clicked.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e">the event of clicking "Delete" button</param>
        private void buttonDelete_Click(object sender, EventArgs e)
        {
            DataGridViewRow row = advancedDataGridViewRecords.Rows[rowIndex];

            ///if condition to check whether the user has the right to delete the record or not
            if (user.userID == (row.DataBoundItem as Record).employeeID || user.userID == 999)
            {
                DialogResult dialogResultDelete;
                dialogResultDelete = MessageBox.Show("Do you really want to delete this record ?", "DELETE A RECORD",
                                                     MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                ///if condition to check whether the user decided to delete this record or not
                if (dialogResultDelete == DialogResult.Yes)
                {
                    dataTable.Rows[rowIndex].Delete();
                }
            }
            else
            {
                MessageBox.Show("You cannot delete this record !\nIt is a property of another employee !");
            }

            DisableChangeDeleteButtons();
        }

        /// <summary>
        /// This method happens when the user clicks once a cell within the datagridview.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void advancedDataGridViewRecords_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            ///if condition to not allow to select the header
            if (e.RowIndex>=0)
            {
                EnableChangeDeleteButtons();
                rowIndex = e.RowIndex;
            }
        }
        
        /// <summary>
        /// This method happens when the user double clicks a cell within the datagridview.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e">provides data by the datagridview whenever mouse is moved within it</param>
        private void advancedDataGridViewRecords_CellMouseDoubleClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            ///if condition to not allow to select the header
            if(e.RowIndex>=0)
                ChangeRecord();
        }
        
        /// <summary>
        /// This method uses the AddOrChangeForm() to change a record data in the datagridview.
        /// </summary>
        private void ChangeRecord()
        {
            //DataGridViewRow row = advancedDataGridViewRecords.Rows[rowIndex];
            /////if condition to check whether the user can change the record or not
            //if (user.userID == (row.DataBoundItem as Record).employeeID || user.userID == 999)
            //{
            //    using (AddOrChangeForm aoc = new AddOrChangeForm() { record = new Record() })
            //    {
            //        ///changing the form text and label text of AddOrChangeForm() to use it to change a record
            //        aoc.Text = "CHANGE";
            //        aoc.labelAddNewData.Text = "CHANGE DATA";
            //        ///filling the comboBoxFullName with the saved data
            //        aoc.comboBoxFullName.SelectedIndex = ((row.DataBoundItem as Record).employeeID) - 1;
            //        ///if condition to check whether the user has the right to change the name of the employee or not
            //        if (user.userID == (row.DataBoundItem as Record).employeeID)
            //        {
            //            aoc.comboBoxFullName.Enabled = false;
            //        }

            //        ///filling the fields of AddOrChangeForm with the saved data 
            //        aoc.dateTimePickerWorkDay.Value = (row.DataBoundItem as Record).workDay;
            //        aoc.numericUpDownDurationOfWork.Value = (row.DataBoundItem as Record).durationOfWork;
            //        aoc.comboBoxTypeOfWork.SelectedIndex = aoc.comboBoxTypeOfWork.Items.IndexOf((row.DataBoundItem as Record).typeOfWork);
            //        aoc.textBoxComment.Text = (row.DataBoundItem as Record).comment;

            //        ///if condition to check whether the user decided to save this change of the record or not
            //        if (aoc.ShowDialog() == DialogResult.OK)
            //        {
            //            aoc.record.recordID = (row.DataBoundItem as Record).recordID;
            //            aoc.record.creationDateTime = (row.DataBoundItem as Record).creationDateTime;
            //            aoc.record.lastUpdatedDateTime = DateTime.Now;
            //            ///if condition to check whether the record is located in the last row of the datagridview or not
            //            if (rowIndex == advancedDataGridViewRecords.Rows.Count - 1)
            //            {
            //                rList.RemoveAt(rowIndex);
            //                rList.Add(aoc.record);
            //            }
            //            else
            //            {
            //                rList.RemoveAt(rowIndex);
            //                rList.Insert(rowIndex, aoc.record);
            //            }
            //        }
            //    }
            //}
            //else
            //{
            //    MessageBox.Show("You cannot change this record !\nIt is a property of another employee !");
            //}

            //DisableChangeDeleteButtons();
        }
        
        /// <summary>
        /// This method enables the buttons "Change" and "Delete".
        /// </summary>
        private void EnableChangeDeleteButtons()
        {
            buttonChange.Enabled = true;
            buttonDelete.Enabled = true;
        }

        /// <summary>
        /// This method disables the buttons "Change" and "Delete".
        /// </summary>
        private void DisableChangeDeleteButtons()
        {
            buttonChange.Enabled = false;
            buttonDelete.Enabled = false;
        }
    }
}