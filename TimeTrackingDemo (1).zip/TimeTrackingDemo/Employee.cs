﻿using System;

namespace TimeTrackingDemo
{
    public class Employee
    {
        public int employeeID { get; set; }
        public String firstName { get; set; }
        public String lastName { get; set; }
        public DateTime dateOfContract { get; set; }

        public Employee ()
        {

        }

        public Employee (int employeeID, String firstName, String lastName, DateTime dateOfContract)
        {
            this.employeeID = employeeID;
            this.firstName = firstName;
            this.lastName = lastName;
            this.dateOfContract = dateOfContract;
        }
    }
}