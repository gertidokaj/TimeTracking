﻿using System;
using System.Windows.Forms;

namespace TimeTrackingDemo
{
    public partial class AddOrChangeForm : Form
    {
        internal Record record;
        EmployeesList eList = new EmployeesList();
        WorkTypesList wList = new WorkTypesList();

        public AddOrChangeForm()
        {
            InitializeComponent();
            ComboBoxFullName_InsertItems();
            ComboBoxWorkTypes_InsertItems();
        }

        /// <summary>
        /// This method disables the "Ok" button when the AddOrChangeForm() is loaded.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void AddOrChangeForm_Load(object sender, EventArgs e)
        {
            buttonOk.Enabled = false;
        }

        /// <summary>
        /// This method inserts items in comboBoxFullName from elist.employees.
        /// </summary>
        private void ComboBoxFullName_InsertItems()
        {
            for (int i = 0; i < eList.employees.Count; i++)
            {
                comboBoxFullName.Items.Insert(i, eList.employees[i].firstName +
                    " " + eList.employees[i].lastName);
            }
        }

        /// <summary>
        /// This method inserts items in comboBoxTypeOfWork from wlist.workTypes.
        /// </summary>
        private void ComboBoxWorkTypes_InsertItems()
        {
            for (int i = 0; i < wList.workTypes.Count; i++)
            {
                comboBoxTypeOfWork.Items.Insert(i, wList.workTypes[i].longName);
            }
        }

        private void comboBoxFullName_SelectedIndexChanged(object sender, EventArgs e)
        {
            SetEmployeeID();
            SetMinMaxWorkDay();
        }

        /// <summary>
        /// This method sets the record's employeeID based on the selected index in the comboBoxFullName.
        /// </summary>
        private void SetEmployeeID()
        {
            record.employeeID = eList.employees[comboBoxFullName.SelectedIndex].employeeID;
        }

        /// <summary>
        /// This method sets the minimum date and maximum date available to pick in the dateTimePickerWorkDay,
        /// the minimum date is dateOfContract taken from eList.employees, the maximum date today.
        /// </summary>
        private void SetMinMaxWorkDay()
        {
            dateTimePickerWorkDay.Enabled = true;
            dateTimePickerWorkDay.MinDate = eList.employees[record.employeeID-1].dateOfContract;
            dateTimePickerWorkDay.MaxDate = DateTime.Now;
        }
        
        /// <summary>
        /// Generic method to check a comboBox if it is selected a value in it or not.
        /// </summary>
        /// <param name="comboBox"></param>
        /// <returns>false if no value selected, true if value selected</returns>
        private bool CheckIfNotNullComboBox (ComboBox comboBox)
        {
            if (comboBox.SelectedItem == null)
                return false;
            return true;
        }

        private void comboBoxFullName_SelectedValueChanged(object sender, EventArgs e)
        {
            EnableOkButton();
        }

        private void comboBoxTypeOfWork_SelectedValueChanged(object sender, EventArgs e)
        {
            EnableOkButton();
        }

        /// <summary>
        /// This method enables the "Ok" button if fulfilled the if condition.
        /// </summary>
        private void EnableOkButton()
        {
            if (CheckIfNotNullComboBox(comboBoxFullName) && CheckIfNotNullComboBox(comboBoxTypeOfWork))
                buttonOk.Enabled = true;
        }

        /// <summary>
        /// This method saves the data entered during the form.
        /// </summary>
        private void SaveRecordData()
        {
            record.firstName = eList.employees[record.employeeID-1].firstName;
            record.lastName = eList.employees[record.employeeID-1].lastName;
            record.workDay = dateTimePickerWorkDay.Value.Date;
            record.durationOfWork = numericUpDownDurationOfWork.Value;
            record.typeOfWork = comboBoxTypeOfWork.Text;
            record.comment = textBoxComment.Text;
        }

        private void buttonOk_Click(object sender, EventArgs e)
        {
            SaveRecordData();
            this.Hide();
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void textBoxComment_TextChanged(object sender, EventArgs e)
        {
            EnableOkButton();
        }

        private void numericUpDownDurationOfWork_ValueChanged(object sender, EventArgs e)
        {
            EnableOkButton();
        }

        private void dateTimePickerWorkDay_ValueChanged(object sender, EventArgs e)
        {
            EnableOkButton();
        }
    }
}