﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace TimeTrackingDemo
{
    public class RecordDataTable
    {   
        public DataTable GetDataTable()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("recordID", typeof(int));
            dt.Columns.Add("employeeID", typeof(int));
            dt.Columns.Add("firstName", typeof(String));
            dt.Columns.Add("lastName", typeof(String));
            dt.Columns.Add("workDay", typeof(DateTime));
            dt.Columns.Add("durationOfWork", typeof(decimal));
            dt.Columns.Add("typeOfWork", typeof(String));
            dt.Columns.Add("creationDateTime", typeof(DateTime));
            dt.Columns.Add("lastUpdatedDateTime", typeof(DateTime));
            dt.Columns.Add("comment", typeof(String));

            return dt;
        }
    }
}
