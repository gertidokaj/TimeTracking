﻿using System;

namespace TimeTrackingDemo
{
    public class User
    {
        public int userID { get; set; }
        public String username { get; set; }

        public User()
        {

        }

        public User(int userID, String username)
        {
            this.userID = userID;
            this.username = username;
        } 
    }
}
