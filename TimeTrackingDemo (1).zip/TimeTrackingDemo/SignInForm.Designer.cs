﻿namespace TimeTrackingDemo
{
	partial class SignInForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.panelSignIn = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelContinueAs = new System.Windows.Forms.Label();
            this.labelExit = new System.Windows.Forms.Label();
            this.labelClearFields = new System.Windows.Forms.Label();
            this.buttonSignIn = new System.Windows.Forms.Button();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panelPassword = new System.Windows.Forms.Panel();
            this.textBoxPassword = new System.Windows.Forms.TextBox();
            this.pictureBoxPassword = new System.Windows.Forms.PictureBox();
            this.panelUsername = new System.Windows.Forms.Panel();
            this.textBoxUsername = new System.Windows.Forms.TextBox();
            this.pictureBoxUsername = new System.Windows.Forms.PictureBox();
            this.labelSignIn = new System.Windows.Forms.Label();
            this.linkLabelConnective = new System.Windows.Forms.LinkLabel();
            this.labelSignInToContinue = new System.Windows.Forms.Label();
            this.panelWelcome = new System.Windows.Forms.Panel();
            this.labelWelcome = new System.Windows.Forms.Label();
            this.labelTimeTrackingSystem = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.pictureBoxConnectiveLogo = new System.Windows.Forms.PictureBox();
            this.panelSignIn.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panelPassword.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPassword)).BeginInit();
            this.panelUsername.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxUsername)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxConnectiveLogo)).BeginInit();
            this.SuspendLayout();
            // 
            // panelSignIn
            // 
            this.panelSignIn.Controls.Add(this.panel1);
            this.panelSignIn.Controls.Add(this.labelExit);
            this.panelSignIn.Controls.Add(this.labelClearFields);
            this.panelSignIn.Controls.Add(this.buttonSignIn);
            this.panelSignIn.Controls.Add(this.panel7);
            this.panelSignIn.Controls.Add(this.panel6);
            this.panelSignIn.Controls.Add(this.panelPassword);
            this.panelSignIn.Controls.Add(this.panelUsername);
            this.panelSignIn.Controls.Add(this.labelSignIn);
            this.panelSignIn.Controls.Add(this.linkLabelConnective);
            this.panelSignIn.Controls.Add(this.labelSignInToContinue);
            this.panelSignIn.Controls.Add(this.panelWelcome);
            this.panelSignIn.Controls.Add(this.labelWelcome);
            this.panelSignIn.Controls.Add(this.labelTimeTrackingSystem);
            this.panelSignIn.Controls.Add(this.panel2);
            this.panelSignIn.Controls.Add(this.pictureBoxConnectiveLogo);
            this.panelSignIn.Location = new System.Drawing.Point(91, 62);
            this.panelSignIn.Name = "panelSignIn";
            this.panelSignIn.Size = new System.Drawing.Size(421, 282);
            this.panelSignIn.TabIndex = 0;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Transparent;
            this.panel1.Controls.Add(this.labelContinueAs);
            this.panel1.Location = new System.Drawing.Point(226, 216);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(185, 25);
            this.panel1.TabIndex = 9;
            // 
            // labelContinueAs
            // 
            this.labelContinueAs.BackColor = System.Drawing.Color.Transparent;
            this.labelContinueAs.Cursor = System.Windows.Forms.Cursors.Hand;
            this.labelContinueAs.Enabled = false;
            this.labelContinueAs.Font = new System.Drawing.Font("Bahnschrift", 10F, System.Drawing.FontStyle.Bold);
            this.labelContinueAs.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(117)))), ((int)(((byte)(214)))));
            this.labelContinueAs.Location = new System.Drawing.Point(0, 0);
            this.labelContinueAs.Name = "labelContinueAs";
            this.labelContinueAs.Size = new System.Drawing.Size(185, 22);
            this.labelContinueAs.TabIndex = 14;
            this.labelContinueAs.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.labelContinueAs.Click += new System.EventHandler(this.labelContinueAs_Click);
            // 
            // labelExit
            // 
            this.labelExit.AutoSize = true;
            this.labelExit.BackColor = System.Drawing.Color.Transparent;
            this.labelExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.labelExit.Font = new System.Drawing.Font("Bahnschrift", 13F, System.Drawing.FontStyle.Bold);
            this.labelExit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(117)))), ((int)(((byte)(214)))));
            this.labelExit.Location = new System.Drawing.Point(298, 251);
            this.labelExit.Name = "labelExit";
            this.labelExit.Size = new System.Drawing.Size(41, 22);
            this.labelExit.TabIndex = 13;
            this.labelExit.Text = "Exit";
            this.labelExit.Click += new System.EventHandler(this.labelExit_Click);
            // 
            // labelClearFields
            // 
            this.labelClearFields.AutoSize = true;
            this.labelClearFields.BackColor = System.Drawing.Color.Transparent;
            this.labelClearFields.Cursor = System.Windows.Forms.Cursors.Hand;
            this.labelClearFields.Font = new System.Drawing.Font("Bahnschrift", 10F, System.Drawing.FontStyle.Bold);
            this.labelClearFields.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(117)))), ((int)(((byte)(214)))));
            this.labelClearFields.Location = new System.Drawing.Point(326, 152);
            this.labelClearFields.Name = "labelClearFields";
            this.labelClearFields.Size = new System.Drawing.Size(85, 17);
            this.labelClearFields.TabIndex = 12;
            this.labelClearFields.Text = "Clear Fields";
            this.labelClearFields.Click += new System.EventHandler(this.labelClearFields_Click);
            // 
            // buttonSignIn
            // 
            this.buttonSignIn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(117)))), ((int)(((byte)(214)))));
            this.buttonSignIn.FlatAppearance.BorderSize = 0;
            this.buttonSignIn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonSignIn.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSignIn.ForeColor = System.Drawing.Color.White;
            this.buttonSignIn.Location = new System.Drawing.Point(226, 180);
            this.buttonSignIn.Name = "buttonSignIn";
            this.buttonSignIn.Size = new System.Drawing.Size(185, 33);
            this.buttonSignIn.TabIndex = 11;
            this.buttonSignIn.Text = "SIGN IN";
            this.buttonSignIn.UseVisualStyleBackColor = false;
            this.buttonSignIn.Click += new System.EventHandler(this.buttonSignIn_Click);
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Gray;
            this.panel7.Location = new System.Drawing.Point(262, 117);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(1, 32);
            this.panel7.TabIndex = 9;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Gray;
            this.panel6.Location = new System.Drawing.Point(262, 68);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1, 32);
            this.panel6.TabIndex = 0;
            // 
            // panelPassword
            // 
            this.panelPassword.BackColor = System.Drawing.Color.Transparent;
            this.panelPassword.Controls.Add(this.textBoxPassword);
            this.panelPassword.Controls.Add(this.pictureBoxPassword);
            this.panelPassword.Location = new System.Drawing.Point(226, 117);
            this.panelPassword.Name = "panelPassword";
            this.panelPassword.Size = new System.Drawing.Size(185, 32);
            this.panelPassword.TabIndex = 10;
            this.panelPassword.Paint += new System.Windows.Forms.PaintEventHandler(this.panelPassword_Paint);
            // 
            // textBoxPassword
            // 
            this.textBoxPassword.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPassword.ForeColor = System.Drawing.Color.DimGray;
            this.textBoxPassword.Location = new System.Drawing.Point(40, 9);
            this.textBoxPassword.Name = "textBoxPassword";
            this.textBoxPassword.Size = new System.Drawing.Size(142, 13);
            this.textBoxPassword.TabIndex = 2;
            this.textBoxPassword.UseSystemPasswordChar = true;
            // 
            // pictureBoxPassword
            // 
            this.pictureBoxPassword.Image = global::TimeTrackingDemo.Properties.Resources.icons8_sign_in_form_password_48;
            this.pictureBoxPassword.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxPassword.Name = "pictureBoxPassword";
            this.pictureBoxPassword.Size = new System.Drawing.Size(29, 26);
            this.pictureBoxPassword.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxPassword.TabIndex = 1;
            this.pictureBoxPassword.TabStop = false;
            // 
            // panelUsername
            // 
            this.panelUsername.BackColor = System.Drawing.Color.Transparent;
            this.panelUsername.Controls.Add(this.textBoxUsername);
            this.panelUsername.Controls.Add(this.pictureBoxUsername);
            this.panelUsername.Location = new System.Drawing.Point(226, 68);
            this.panelUsername.Name = "panelUsername";
            this.panelUsername.Size = new System.Drawing.Size(185, 32);
            this.panelUsername.TabIndex = 8;
            this.panelUsername.Paint += new System.Windows.Forms.PaintEventHandler(this.panelUsername_Paint);
            // 
            // textBoxUsername
            // 
            this.textBoxUsername.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxUsername.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxUsername.ForeColor = System.Drawing.Color.DimGray;
            this.textBoxUsername.Location = new System.Drawing.Point(40, 9);
            this.textBoxUsername.Name = "textBoxUsername";
            this.textBoxUsername.Size = new System.Drawing.Size(142, 13);
            this.textBoxUsername.TabIndex = 1;
            // 
            // pictureBoxUsername
            // 
            this.pictureBoxUsername.Image = global::TimeTrackingDemo.Properties.Resources.icons8_username_24;
            this.pictureBoxUsername.Location = new System.Drawing.Point(3, 3);
            this.pictureBoxUsername.Name = "pictureBoxUsername";
            this.pictureBoxUsername.Size = new System.Drawing.Size(29, 26);
            this.pictureBoxUsername.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxUsername.TabIndex = 0;
            this.pictureBoxUsername.TabStop = false;
            // 
            // labelSignIn
            // 
            this.labelSignIn.AutoSize = true;
            this.labelSignIn.BackColor = System.Drawing.Color.Transparent;
            this.labelSignIn.Font = new System.Drawing.Font("Bauhaus 93", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSignIn.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(117)))), ((int)(((byte)(214)))));
            this.labelSignIn.Location = new System.Drawing.Point(251, 13);
            this.labelSignIn.Name = "labelSignIn";
            this.labelSignIn.Size = new System.Drawing.Size(140, 42);
            this.labelSignIn.TabIndex = 7;
            this.labelSignIn.Text = "SIGN IN";
            // 
            // linkLabelConnective
            // 
            this.linkLabelConnective.ActiveLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(117)))), ((int)(((byte)(214)))));
            this.linkLabelConnective.AutoSize = true;
            this.linkLabelConnective.BackColor = System.Drawing.Color.Transparent;
            this.linkLabelConnective.Font = new System.Drawing.Font("Bahnschrift", 13F, System.Drawing.FontStyle.Bold);
            this.linkLabelConnective.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabelConnective.LinkColor = System.Drawing.Color.DimGray;
            this.linkLabelConnective.Location = new System.Drawing.Point(21, 251);
            this.linkLabelConnective.Name = "linkLabelConnective";
            this.linkLabelConnective.Size = new System.Drawing.Size(171, 22);
            this.linkLabelConnective.TabIndex = 6;
            this.linkLabelConnective.TabStop = true;
            this.linkLabelConnective.Text = "www.connective.biz";
            this.linkLabelConnective.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabelConnective_LinkClicked);
            // 
            // labelSignInToContinue
            // 
            this.labelSignInToContinue.AutoSize = true;
            this.labelSignInToContinue.BackColor = System.Drawing.Color.Transparent;
            this.labelSignInToContinue.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.labelSignInToContinue.ForeColor = System.Drawing.Color.Black;
            this.labelSignInToContinue.Location = new System.Drawing.Point(9, 172);
            this.labelSignInToContinue.Name = "labelSignInToContinue";
            this.labelSignInToContinue.Size = new System.Drawing.Size(198, 17);
            this.labelSignInToContinue.TabIndex = 5;
            this.labelSignInToContinue.Text = "SIGN IN TO CONTINUE ACCESS";
            // 
            // panelWelcome
            // 
            this.panelWelcome.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(117)))), ((int)(((byte)(214)))));
            this.panelWelcome.Location = new System.Drawing.Point(9, 166);
            this.panelWelcome.Name = "panelWelcome";
            this.panelWelcome.Size = new System.Drawing.Size(197, 3);
            this.panelWelcome.TabIndex = 4;
            // 
            // labelWelcome
            // 
            this.labelWelcome.AutoSize = true;
            this.labelWelcome.BackColor = System.Drawing.Color.Transparent;
            this.labelWelcome.Font = new System.Drawing.Font("Segoe UI", 18F, System.Drawing.FontStyle.Bold);
            this.labelWelcome.ForeColor = System.Drawing.Color.Black;
            this.labelWelcome.Location = new System.Drawing.Point(6, 131);
            this.labelWelcome.Name = "labelWelcome";
            this.labelWelcome.Size = new System.Drawing.Size(200, 32);
            this.labelWelcome.TabIndex = 3;
            this.labelWelcome.Text = "WELCOME PAGE";
            // 
            // labelTimeTrackingSystem
            // 
            this.labelTimeTrackingSystem.AutoSize = true;
            this.labelTimeTrackingSystem.BackColor = System.Drawing.Color.Transparent;
            this.labelTimeTrackingSystem.Font = new System.Drawing.Font("Bahnschrift", 13F, System.Drawing.FontStyle.Bold);
            this.labelTimeTrackingSystem.ForeColor = System.Drawing.Color.DimGray;
            this.labelTimeTrackingSystem.Location = new System.Drawing.Point(3, 68);
            this.labelTimeTrackingSystem.Name = "labelTimeTrackingSystem";
            this.labelTimeTrackingSystem.Size = new System.Drawing.Size(209, 22);
            this.labelTimeTrackingSystem.TabIndex = 2;
            this.labelTimeTrackingSystem.Text = "TIME TRACKING SYSTEM";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Black;
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Location = new System.Drawing.Point(212, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(5, 282);
            this.panel2.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Black;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(5, 282);
            this.panel3.TabIndex = 2;
            // 
            // pictureBoxConnectiveLogo
            // 
            this.pictureBoxConnectiveLogo.BackColor = System.Drawing.Color.Transparent;
            this.pictureBoxConnectiveLogo.Image = global::TimeTrackingDemo.Properties.Resources.logo222_connective_small_transparent;
            this.pictureBoxConnectiveLogo.Location = new System.Drawing.Point(22, 3);
            this.pictureBoxConnectiveLogo.Name = "pictureBoxConnectiveLogo";
            this.pictureBoxConnectiveLogo.Size = new System.Drawing.Size(170, 52);
            this.pictureBoxConnectiveLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxConnectiveLogo.TabIndex = 0;
            this.pictureBoxConnectiveLogo.TabStop = false;
            // 
            // SignInForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::TimeTrackingDemo.Properties.Resources.employee_time_tracking_apps__2_;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(601, 402);
            this.Controls.Add(this.panelSignIn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.Name = "SignInForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Time Tracking - Demo App";
            this.Load += new System.EventHandler(this.SignInForm_Load);
            this.panelSignIn.ResumeLayout(false);
            this.panelSignIn.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panelPassword.ResumeLayout(false);
            this.panelPassword.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxPassword)).EndInit();
            this.panelUsername.ResumeLayout(false);
            this.panelUsername.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxUsername)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxConnectiveLogo)).EndInit();
            this.ResumeLayout(false);

		}


        #endregion

        private System.Windows.Forms.Panel panelSignIn;
        private System.Windows.Forms.PictureBox pictureBoxConnectiveLogo;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label labelTimeTrackingSystem;
        private System.Windows.Forms.Label labelWelcome;
        private System.Windows.Forms.Panel panelWelcome;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label labelSignInToContinue;
        private System.Windows.Forms.LinkLabel linkLabelConnective;
        private System.Windows.Forms.Label labelSignIn;
        private System.Windows.Forms.Panel panelUsername;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panelPassword;
        private System.Windows.Forms.PictureBox pictureBoxUsername;
        private System.Windows.Forms.PictureBox pictureBoxPassword;
        private System.Windows.Forms.TextBox textBoxPassword;
        private System.Windows.Forms.TextBox textBoxUsername;
        private System.Windows.Forms.Button buttonSignIn;
        private System.Windows.Forms.Label labelExit;
        private System.Windows.Forms.Label labelClearFields;
        private System.Windows.Forms.Label labelContinueAs;
        private System.Windows.Forms.Panel panel1;
    }
}

