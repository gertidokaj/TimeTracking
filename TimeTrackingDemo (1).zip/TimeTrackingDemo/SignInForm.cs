﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace TimeTrackingDemo
{
	public partial class SignInForm : Form
	{
        User userS = new User();
        UsersList uList = new UsersList();

        public SignInForm()
		{
			InitializeComponent();
            ///to paint the SignIn panel with a color structure created from the base color, but with the new alpha value
            ///to make it transparent
            panelSignIn.BackColor = Color.FromArgb(220, Color.White);
        }

        private void SignInForm_Load(object sender, EventArgs e)
        {
            ///getting the username from Windows system
            String username = System.Environment.UserName;
            ///for iterator to iterate the uList
            for (int i = 0; i < uList.users.Count; i++)
            {
                ///if condition to check whether the username taken from the Windows system is or not in the uList.users
                if (username == uList.users[i].username)
                {
                    userS.userID = uList.users[i].userID;
                    userS.username = uList.users[i].username;
                    labelContinueAs.Enabled = true;
                    labelContinueAs.Text = "Continue as " + username;
                    break;
                }
            }
        }

        /// <summary>
        /// This method paints the Username panel.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void panelUsername_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, panelUsername.ClientRectangle, Color.Gray, ButtonBorderStyle.Solid);
        }

        /// <summary>
        /// This method paints the Password panel.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void panelPassword_Paint(object sender, PaintEventArgs e)
        {
            ControlPaint.DrawBorder(e.Graphics, panelPassword.ClientRectangle, Color.Gray, ButtonBorderStyle.Solid);
        }

        /// <summary>
        /// This method directs the user to the link below in his custom web browser.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void linkLabelConnective_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            System.Diagnostics.Process.Start("http://www.connective.biz");
        }

        /// <summary>
        /// This method clears Username and Password textboxes when user clicks "Clear Fields".
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void labelClearFields_Click(object sender, EventArgs e)
        {
            ClearTextBoxes();
        }

        /// <summary>
        /// This method closes the aplication.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void labelExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        /// <summary>
        /// This method loads the HomePageForm() if Username and Password are completed successfully.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonSignIn_Click(object sender, EventArgs e)
        {
            ///if condition to check whether administrator credentials are written successfully
            if (CheckAdminCredentials())
            {
                HomePageForm hp = new HomePageForm();
                hp.user = new User(999, "administrator");
                hp.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Incorrect username or password.\nPlease, try again !");
                ClearTextBoxes();
            }
        }

        /// <summary>
        /// This method loads the HomePageForm() if ContinueAs label is enabled.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void labelContinueAs_Click(object sender, EventArgs e)
        {
            HomePageForm hp = new HomePageForm();
            hp.user = userS;
            hp.Show();
            this.Hide();
        }

        /// <summary>
        /// This method clears the Username and Password textboxes and sends the focus to the Username textbox.
        /// </summary>
        private void ClearTextBoxes()
        {
            textBoxUsername.Clear();
            textBoxPassword.Clear();
            textBoxUsername.Focus();
        }

        /// <summary>
        /// This method checks the administrator credentials in the Username and Password textboxes.
        /// </summary>
        /// <returns>true when credentials match, false when credentials do not match</returns>
        private bool CheckAdminCredentials()
        {
            if(textBoxUsername.Text == "admin" && textBoxPassword.Text == "admin")
                return true;
            return false;
        }
    }
 }
