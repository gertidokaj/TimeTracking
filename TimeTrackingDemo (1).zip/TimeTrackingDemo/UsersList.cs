﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimeTrackingDemo
{
    public class UsersList
    {
        internal List<User> users = GetListOfUsers();

        private static List<User> GetListOfUsers ()
        {
            List<User> listofUsers = new List<User>();
            EmployeesList eList = new EmployeesList();
            for (int i = 0; i < eList.employees.Count; i++)
            {
                var user = new User();
                user.userID = eList.employees[i].employeeID;
                user.username = (eList.employees[i].firstName.ToString().ToLower() + "." 
                                + eList.employees[i].lastName.ToString().ToLower()).Replace(" ", string.Empty);
                listofUsers.Add(user);
            }
            return listofUsers;
        }
    }
}
