﻿using System;

namespace TimeTrackingDemo
{
    public class WorkType
    {
        public int workID { get; set; }
        public String longName { get; set; }
        public String vacation { get; set; }
        public String workTime { get; set; }
        public String productive { get; set; }

        public WorkType()
        {

        }

        public WorkType(int workID, String longName, String vacation, String workTime, String productive)
        {
            this.workID = workID;
            this.longName = longName;
            this.vacation = vacation;
            this.workTime = workTime;
            this.productive = productive;
        }  
    }
}