﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;

namespace TimeTrackingDemo
{
    public class WorkTypesList
    {
        private static String pathWorkTypes = @"E:\timetrackingdemo\TimeTrackingDemo\bin\Debug\WorkTypes.csv";

        internal List<WorkType> workTypes = readWorkTypeCSVFile(pathWorkTypes);

        private static List<WorkType> readWorkTypeCSVFile(String path)
        {
            var lines = File.ReadAllLines(path).Skip(1);
            var workTypesList = new List<WorkType>();
            foreach (var line in lines)
            {
                var values = line.Split(',');
                if (values.Length == 5)
                {
                    var workType = new WorkType(Int16.Parse(values[0]), values[1], values[2], values[3], values[4]);
                    workTypesList.Add(workType);
                }
            }
            return workTypesList;
        }
    }
}