﻿using System;

namespace TimeTrackingDemo
{
    public class Record
    {
        public int recordID { get; set; }
        public int employeeID { get; set; }
        public String firstName { get; set; }
        public String lastName { get; set; }
        public DateTime workDay { get; set; }
        public decimal durationOfWork { get; set; }
        public String typeOfWork { get; set; }
        public DateTime creationDateTime { get; set; }
        public DateTime lastUpdatedDateTime { get; set; }
        public String comment { get; set; }

        public Record()
        {

        }

        public Record(int recordID, int employeeID, String firstName, String lastName, DateTime workDay, decimal durationOfWork,
            String typeOfWork, DateTime creationDateTime, DateTime lastUpdatedDateTime, String comment)
        {
            this.recordID = recordID;
            this.employeeID = employeeID;
            this.firstName = firstName;
            this.lastName = lastName;
            this.workDay = workDay;
            this.durationOfWork = durationOfWork;
            this.typeOfWork = typeOfWork;
            this.creationDateTime = creationDateTime;
            this.lastUpdatedDateTime = lastUpdatedDateTime;
            this.comment = comment;
        }
    }
}