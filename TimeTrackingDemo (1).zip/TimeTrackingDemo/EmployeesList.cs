﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;

namespace TimeTrackingDemo
{
    public class EmployeesList
    {
        private static String pathEmployees = @"E:\timetrackingdemo\TimeTrackingDemo\bin\Debug\Employees.csv";
            
        internal List<Employee> employees = readEmployeeCSVFile(pathEmployees);

        private static List<Employee> readEmployeeCSVFile(String path)
        {
            var lines = File.ReadAllLines(path).Skip(1);
            var employeeList = new List<Employee>();
            foreach (var line in lines)
            {
                var values = line.Split(',');
                if (values.Length == 4)
                {
                    var employee = new Employee(int.Parse(values[0]), values[1], values[2], DateTime.Parse(values[3]));
                    employeeList.Add(employee);
                }
            }
            return employeeList;
        }
    }
}